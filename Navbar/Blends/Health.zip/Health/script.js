document.getElementById('add-to-cart-btn').addEventListener('click', function() {
    var quantity = document.getElementById('quantity').value;
    alert('Added ' + quantity + ' Mitochondrial Health Bundles to cart!');
    // Here you can add further logic for adding the product to the cart.
});
